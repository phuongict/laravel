<?php
/**
 * Created by PhpStorm.
 * User: phamphuong
 * Author: Phạm Văn Phương
 * Date: 04/12/2019
 * Time: 09:33
 */
return [
    'id' => '/[0-9]+/',
    'abcde' => 'sasasad'
];
