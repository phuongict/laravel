<?php
/**
 * Created by PhpStorm.
 * User: phamphuong
 * Author: Phạm Văn Phương
 * Date: 04/12/2019
 * Time: 09:44
 */
function test(){
    return 'halo';
}
