<?php
/**
 * Created by PhpStorm.
 * User: phamphuong
 * Author: Phạm Văn Phương
 * Date: 04/12/2019
 * Time: 16:27
 */
return [
    'list_users' => 'Danh sách người dùng'
];
