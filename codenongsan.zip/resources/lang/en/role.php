<?php
/**
 * Created by PhpStorm.
 * User: phamphuong
 * Author: Phạm Văn Phương
 * Date: 17/12/2019
 * Time: 11:23
 */
return [
    'role' => 'Role',
    'create_role' => 'Create role',
    'edit_role' => 'Edit role',
    'delete_role' => 'Delete role',
];
