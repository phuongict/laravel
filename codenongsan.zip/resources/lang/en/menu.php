<?php
/**
 * Created by PhpStorm.
 * User: phamphuong
 * Author: Phạm Văn Phương
 * Date: 18/12/2019
 * Time: 16:15
 */
return [
    'order' => 'Order',
    'menu' => 'Menu',
    'create_menu' => 'Create menu',
    'edit_menu' => 'Edit menu',
    'delete_menu' => 'Delete menu',
    'no_parent' => 'No parent',
    'no_permission' => 'No permission',
    'choose_permission' => 'Choose permission',
    'choose_parent' => 'Choose parent',
    'sort_menu' => 'Sort menu',
    'error_sort_menu' => 'Error sort menu',
    'sort_success' => 'Sort menu is successful'
];
