<?php
/**
 * Created by PhpStorm.
 * User: phamphuong
 * Author: Phạm Văn Phương
 * Date: 16/12/2019
 * Time: 23:01
 */
return [
    'permission' => 'permission',
    'create_permission' => 'Create permission',
    'edit_permission' => 'Edit permission',
    'delete_permission' => 'Delete permission',
    'choose_permission_parent' => 'Choose permission parent',
    'no_parent' => 'No parent',
];
