@extends('frontends.layouts.app')
@section('_title', $_title)
@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Title</h4>

        </div>
        <div class="card-body">
            <p class="card-text">Text</p>
        </div>
    </div>
@endsection
