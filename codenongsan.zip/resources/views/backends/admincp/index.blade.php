@extends('backends.layouts.app')
@section('_title', 'Admin Control Panel')
@section('content')
    <h1>Welcome to admin control panel</h1>
    @endsection
